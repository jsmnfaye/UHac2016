<?php

						
    require("/php/database.php");
    require("/php/session.php");

?>

<!DOCTYPE html>
<html lang="en">

	<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>Admin | Seek-a-Pedia</title>

		<!-- Styles -->
		<link href="css/bootstrap.min.css" rel="stylesheet">

		<link href="css/adminCSS.css" rel="stylesheet">

		<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

	</head>

	<body>

		<div id="wrapper">
		

			<!-- Navigation -->
			<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="docHome.php"><img src="img/logo.png" id="logo"></a>
				</div>
				<!-- /.navbar-header -->

				<ul class="nav navbar-top-links navbar-right">
					
				</ul>
				<!-- /.navbar-top-links -->

				<div class="navbar sidebar" role="navigation">
					<div class="sidebar-nav navbar-collapse">
						<h4 class="admin"><i class="fa fa-2x fa-user-md fa-fw"></i><b>Doctor <?php echo $name;?><b></h4>
						<h6 class="text-center" style="color:green; margin-top:-10px;"><b>Available</b></h6>

						<ul class="nav" id="side-menu">
							<li class="divider"></li>
							
							<li class="currentLink">
								<a href="docHome.php"><i class="fa fa-lg fa-home fa-fw"></i> Home</a>
							</li>
												
							<li> 
								<a href="docProfile.php"><i class="fa fa-lg fa-user-md fa-fw"></i> Profile</a>
							</li>
							
							<li>
								<a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
							</li>
													
						</ul>
					</div>
					<!-- /.sidebar-collapse -->
				</div>
				<!-- /.navbar-static-side -->
			</nav>

			<div id="page-wrapper">
				<div class="row">
					<div class="col-lg-12">
						<h1 class="page-header">Patient Record</h1>
						<ol class="breadcrumb pull-right">
							<li class="breadcrumb-item" id="brePatients"><a href="docHome.php">Home</a></li>
							<li class="breadcrumb-item active" id="active">Patient Record</li> 
						</ol>
					</div>
					<!-- /.col-lg-12 -->
				</div>
				<!-- /.row -->
				<div class="row">
					<div class="col-lg-7 col-md-6">
						<div class="panel panel-red">
							<div class="panel-heading">
								Add Record
							</div>
																	
							<div class="panel-body" style="margin:5px 20px;">
								<form   method="post" class="form" role="form">
									<div class="form-group">
										<label for="date" style="float:right;">Date: <p id="" style="display:inline-block;"><?php echo "2016-08-28" ?></p></label>
										<br><br>
										<label for="diag">Diagnosis</label>
										<input type="text" class="form-control" id="diag1" placeholder="Enter diagnosis here">
										<label for="find">Findings Summary</label>
										<textarea class="form-control" rows="2" placeholder="Enter findings summary here" id="find1"></textarea>
										<label for="med">Prescribed Medicine</label>
										<input type="text" class="form-control" id="med1" placeholder="Enter prescribed medicine here">
										<div class="form-inline">
											<input type="text" class="form-control form-horizontal" id="dos1" placeholder="Enter dosage here">
											<select class="form-control" style="margin-top:1px;">
												<option>ml</option>
												<option>mg</option>
											</select>
										</div>
										<label for="in">Intake Schedule</label>
										<div class="form-inline">
											<input type="text" class="form-control form-horizontal" id="days1" placeholder="Enter no. of days">
											<input type="text" class="form-control form-horizontal" id="time1" placeholder="Enter time schedule">
										</div>
										
										<br>
										<button type="submit" class="btn btn-default" name="submit">Save</button>
										<form  action="prescription.php" method="post" class="form" role="form">	
							   
							   
							
							  <button type="Submit" class="btn btn-sub" name="Submit">View The Prescription</button>
							  </form>
									</div>
								</form>
								
							</div>
							<!-- /.panel-body -->
						</div>
						<!-- /.panel -->
					</div>
					
					<div class="col-lg-5 col-md-6" id="patientRecords">
						<div class="panel panel-red">
							<div class="panel-heading">
								<div class="row">
									<div class="col-xs-3">
										<i class="fa fa-stethoscope fa-5x"></i>
									</div>
									<?php
						    require ("database.php");
							$patientID = $_GET['id'];
							$sql="SELECT COUNT(CheckupID) as 'numbercheckup' from `check-up details` where PatientID ='".$patientID."'";
							$result = mysqli_query($conn,$sql);
						
						?>	
                                <div class="col-xs-9 text-right">
								
								<?php while ($records = mysqli_fetch_object($result)){?>
                                    <h2><b><?php echo $records->numbercheckup;?></b></h2>
									<?php } ?>
										<h5>Records</h5>
									</div>
								</div>
							</div>
							<a onclick="showPatientRecs()">
								<div class="panel-footer">
									<span class="pull-left" id="viewR">View Records</span>
									<span class="pull-left" id="hideR" style="display:none;">Hide Records</span>
									<span class="pull-right"><i class="fa fa-arrow-circle-right" id ="rightR"></i>
									<i class="fa fa-arrow-circle-left" id="leftR" style="display:none;"></i></span>
									<div class="clearfix"></div>
								</div>
							</a>
						</div>
						<?php
								require ("database.php");
								$sql="SELECT patient.PatientID,`check-up details`.Diagnosis,`check-up details`.FindingsSummary,`check-up details`.CheckupID,`check-up details`.doctorID,`check-up details`.`Date`,`prescribed medicine`.MedicineName,`prescribed medicine`.MedicineDosage,`prescribed medicine`.UnitofDosage FROM patient RIGHT JOIN `check-up details` ON `check-up details`.`PatientID`= patient.PatientID LEFT JOIN `prescribed medicine` ON `prescribed medicine`.MedicineID= `check-up details`.MedicineID WHERE `check-up details`.doctorID =  '".$doctorID."' AND patient.patientID = '".$patientID."'";
								$result = mysqli_query($conn,$sql);
							
							?>	
						
						<table class="table table-hover table-bordered table-fixed" style="display:none;" id="patientRecs">
							<thead>
								<tr>
									<th>Date</th>
									<th>Diagnosis</th>
									<th>Findings Summary</th>
									<th>Prescription</th>
								</tr>
							</thead>
							<tbody>
								<?php while ($patient = mysqli_fetch_object($result)){?>
								  <tr class="gradeA">
											<td><?php echo $patient -> Date?></td>
											<td><?php echo $patient -> Diagnosis?></td>
											<td><?php echo $patient -> FindingsSummary?></td>
			
											
											<td><a onclick="showDetails()"><i class="fa fa-heart-o fa-fw"></i></a> <?php echo $patient -> MedicineName?><br>
										<span class="pull-right text-muted small" id="hospSched" style="display:none;"><em><?php echo $patient -> MedicineDosage?> <?php echo $patient -> UnitofDosage?></br></em></span></td>
											
											
											<th><a onclick="showProfileAndRecords()?id=<?php echo $patient->PatientID;?>">View Record</a> | <a href="">Add Record</a></th>
										</tr>
						<?php } ?>
							</tbody>
						</table>
					
					</div>
					
				</div>
				<!-- /.row -->
			 
			</div>
			<!-- /#page-wrapper -->

		</div>
		<!-- /#wrapper -->

		 <!-- Scripts -->
		<script src="js/jquery.min.js"></script>

		<script src="js/bootstrap.min.js"></script>
		
		<script src="js/docJS.js"></script>
		
		<script src="js/sb-admin-2.js"></script>
		<script src="js/metisMenu.min.js"></script> 

	</body>

</html>
