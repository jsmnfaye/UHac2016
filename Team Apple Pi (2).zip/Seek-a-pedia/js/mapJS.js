var locations = [
        ['St. Michael\'s Medical Center', 14.5826228, 121.0534564, '2'],
        ['St. Patrick\'s Medical Systems', 14.585618, 121.048296, '1'],
        ['Galileo Surgicenter and Vision Institute', 14.5841234, 121.0558927, '3'],
        ['Medical Plaza Ortigas', 14.5803972, 121.0594192, '2'],
        ['PhilhealthCare Incorporated', 14.585058, 121.056691, '4']
      ];

      function initMap() {
        var test = {lat: 14.583497, lng: 121.057149};
        var map = new google.maps.Map(document.getElementById('map'), {
          center: test,
          zoom: 15
        });

        setMarkers(map,locations)
      }

      function setMarkers(map,locations){

        var marker, i;

        for (i = 0; i < locations.length; i++){

           var a = locations[i][0]
           var lat = locations[i][1]
           var long = locations[i][2]
           var add =  locations[i][3]

           latlngset = new google.maps.LatLng(lat, long);

           var marker = new google.maps.Marker({
              map: map, title: a , position: latlngset
            });

            map.setCenter(marker.getPosition())
            var content = '<h2 class="firstHeading">'+a+'</h2>'+'No. of Pediatricians: '+add+'<br><br><button type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModal">See list of Pediatricians</button>'

            var infowindow = new google.maps.InfoWindow()

            google.maps.event.addListener(marker,'click', (function(marker,content,infowindow){
              return function() {
               infowindow.setContent(content);
               infowindow.open(map,marker);
              };
            })(marker,content,infowindow));

          }
      }