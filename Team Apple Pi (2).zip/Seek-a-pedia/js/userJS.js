function showConfirm() {
    alert("Appointment made. You will be notified once your appointment is approved.");
}

 