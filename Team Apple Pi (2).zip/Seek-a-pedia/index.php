<?php
    include('phpuser/loginadmin.php'); // Includes Login Script

    if(isset($_SESSION['login_user'])){
        header("location: userHome.php");
    }
?>


<!DOCTYPE html>
<html lang="en">

	<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>Seek-a-Pedia</title>

		<!-- Styles -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		
		<link href="css/userCSS.css" rel="stylesheet">

		<!-- Custom Fonts -->
		<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

	</head>

	<body>

		<div id="wrapper">
			
			<nav class="navbar navbar-default navbar-fixed-top">
			  <div class="container">
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				  <a class="navbar-brand" href="#"><img src="img/logo.png"></a>
				</div>
				<div id="navbar" class="navbar-collapse collapse">
				
				  <form class="navbar-form navbar-right" role="form" action="" method="post">
					<div class="form-group">
					  <input type="text" placeholder="User" id="user" name="user" class="form-control">
					 <input type="password" placeholder="Password" id="pwd" name="pwd" class="form-control">
					</div>
					<button type="submit" class="btn btn-danger" name= "login">Sign in</button>
				  </form>
				 
				</div><!--/.navbar-collapse -->
			  </div>
			</nav>
		
	
		<div id="page-wrapper">
			<div class="container">
				<div class="col-lg-12"><br><br>
					<center>
					<img src="img/name2.png">
					<br>
					<h3>The future of Pediacare, making difference in the small people.</h3>
					</center>
				</div>
			</div>
				<div class="container">
					<div class="row"> 
					<div class="col-lg-4">
						
					</div>
					
					<div class="col-lg-5">
						<h3>Why use our App?</h3>
						Seek-a-Pedia makes it easier for searching for a pediatrician for your child all in the comfort
						of your own home. It will be responsible for tracking your location and the neearest hospitals or clinics
						
						<h3>Start Now</h3>
						Login or register for a new account below.<br><br>
						<button class="btn btn-block btn-danger">Register an account</button>
					 </div>
					</div>
				</div>
				
			
		</div>
		<!-- /#page-wrapper -->
		
		
		
		</div>
		<!-- /#wrapper -->

		<div class="box">
			<div class="col-lg-12"><br><br>
				<center>
					<div class="row">
					  <div class="col-md-12 col-xs-12">
					  <center>
				
						<div class="row in"><br><br><br>
						  <div class="col-md-2 col-xs-12">
							<i class="fa fa-search fa-5x" aria-hidden="true"></i>
						  </div>
						  <div class="col-md-4 col-xs-12 panget">
							Search for hospitals or clinics that are nearest to your location for
							your convenience.
						  </div>
						  <div class="col-md-2 col-xs-12">
							<i class="fa fa-calendar-check-o fa-5x" aria-hidden="true"></i>
						  </div>
						  <div class="col-md-4 col-xs-12 panget">
							Doctors can keep track of their scheduled appointments, and parents get notified
							on the day of the appointment they scheduled with their doctor.
						  </div>
						</div><br><br>
						<div class="row in">
						  <div class="col-md-2 col-xs-12">
							<i class="fa fa-server fa-5x" aria-hidden="true"></i>
						  </div>
						  <div class="col-md-4 col-xs-12 panget">
							Prescriptions and check-up diagnosis are stored digitally in addition
							to being printed for easy access and to avoid loss of hard copies.
						  </div>
						  <div class="col-md-2 col-xs-12">
							<i class="fa fa-tablet fa-5x" aria-hidden="true"></i>
						  </div>
						  <div class="col-md-4 col-xs-12 panget">
							Medical history is stored and kept, making it accessible anytime.
						  </div>
						</div>
					  </center>
						</div>
					</div>

				</center>
			</div>
		</div>
			<!-- Footer -->
			<footer class="text-center">
				<div class="footer-above">
					<div class="container">
						<div class="row">
							<div class="footer-col col-md-4">
								<h3></h3>
								<p></p>
							</div>
							<div class="footer-col col-md-4">
								<ul class="list-inline">
									<li>
										<a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-facebook"></i></a>
									</li>
									<li>
										<a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-twitter"></i></a>
									</li>
									<li>
										<a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-linkedin"></i></a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="footer-below">
					<div class="container">
						<div class="row">
							<div class="col-lg-12">
								Copyright &copy; Seek-A-Pedia 2016
							</div>
						</div><br><br>
					</div>
				</div>
			</footer>
		<!-- Scripts -->
		<script src="js/jquery.min.js"></script>

		<script src="js/bootstrap.min.js"></script>

		<script src="js/sb-admin-2.js"></script>
		
	</body>

</html>
