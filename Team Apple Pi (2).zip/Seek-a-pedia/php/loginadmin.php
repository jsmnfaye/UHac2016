<?php

    require("php/database.php");
    
    session_start(); // Starting Session
    $error=''; // Variable To Store Error Message
    if (isset($_POST['login'])) {
        if (empty($_POST['user']) || empty($_POST['pwd'])) {
            $error = "Username or Password is invalid";
        }
        else
        {
            // Define $username and $password
            $email=$_POST['user'];
            $pwd=$_POST['pwd'];
            // SQL query to fetch information of registerd users and finds user match.
            $sql="SELECT count(*) AS Total FROM account WHERE Username = '".$email."' AND Password = '".$pwd."'";
            $res = mysqli_query($conn,$sql);
            while ($data = mysqli_fetch_array($res)) {
                $total = $data['Total'];
            }
            if ($total == 1) {
                $_SESSION['login_user']=$email; // Initializing Session
                echo    "<script>
                            alert('Access Granted!');
                            window.location.href='/php/session.php';
                        </script>";
            } 
			else{
                echo    "<script>
                            alert('Access Denied. Incorrect Username or Password');
                            window.location.href='docLogin.php';
                        </script>";
            }
            

        }
    }
?>