<?php
	require("phpuser/database.php");
	session_start();// Starting Session
	// Storing Session
	$user_check=$_SESSION['login_user'];
	// SQL Query To Fetch Complete Information Of User
	$sql="select account.AccountID,account.Username,patient.PatientID,patient.LastName,patient.FirstName,patient.MiddleName from account RIGHT JOIN parent ON parent.AccountID = account.AccountID LEFT JOIN patient ON patient.ParentID = parent.ParentID WHERE account.Username = '".$user_check."'";
	$res = mysqli_query($conn,$sql);
	$row = mysqli_fetch_array($res);
	$login_session = $row['Username'];

	$name = $row['FirstName'];
	$accountID = $row['AccountID'];
	$num = $row['Number of appointment'];
	$patientID = $row['PatientID'];
	

	if(!isset($login_session)){
		mysqli_close($connection); // Closing Connection
		header('Location: index.php'); // Redirecting To Home Page
	}
?>