<?php
$serverName = 'localhost'; //serverName\instanceName
$conn = mysqli_connect( $serverName, 'root','','seek_a_pedia');

?>
