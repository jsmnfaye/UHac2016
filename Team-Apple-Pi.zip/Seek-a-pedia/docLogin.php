<?php
    include('php/loginadmin.php'); // Includes Login Script

    if(isset($_SESSION['login_user'])){
        header("location: docHome.php");
    }
?>

<!DOCTYPE html>
<html lang="en">

	<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>Seek-a-Pedia</title>

		<!-- Styles -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		
		<link href="css/userCSS.css" rel="stylesheet">

		<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

		<style>body{overflow-x:hidden;}</style>
		
	</head>

	<body>

		<div id="wrapper">
			<center>
			<div id="page-wrapper">
				<div class="container">
					<div class="col-lg-12">
						<br><br>
						<img src="img/name.png">
						<br>
						<h3>We seek the best pedias. Fast. Free. Fun. Charot</h3>
						
					</div>
				</div>
				<div class="container">
						<div class="col-lg-3 col-md-3"></div>
						<div class="col-lg-6 col-md-6 col-xs-12">
							<form role="form" action="" method="post">	
								<div class="form-group">
									<br><br><br>
									<input type="text" class="form-control" id="user" name="user" placeholder="Enter username here">
									<input type="password" class="form-control" id="pwd" name="pwd" placeholder="Enter password here"><br>
									<br><button type="submit" class="btn searchbutton"  name= "login" ><b>Login</b></button> 	
									
								</div>
							</form>
						</div>	
				</div>
				
			</div>
			<!-- /#page-wrapper -->
			</center>
		
		<!-- Footer -->
		<footer class="text-center" style="margin-top:-100px;"><br><br>
			<div class="row">
				<ul class="list-inline">
					<li><a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-facebook"></i></a></li>
					<li><a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-twitter"></i></a></li>
					<li><a href="#" class="btn-social btn-outline"><i class="fa fa-fw fa-linkedin"></i></a></li>
				</ul>
			</div>
					<div class="col-lg-12">
							Copyright &copy; Seek-A-Pedia 2016
						</div>
		</footer>
		
		</div>
		<!-- /#wrapper -->

		<!-- Scripts -->
		<script src="js/jquery.min.js"></script>

		<script src="js/bootstrap.min.js"></script>

		<script src="js/sb-admin-2.js"></script>
		
	</body>

</html>

