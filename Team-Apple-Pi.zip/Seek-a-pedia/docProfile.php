<?php

						
    require("database.php");
    require("/php/session.php");

?>



<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin | Seek-a-Pedia</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/adminCSS.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html"><img src="img/logo.png" id="logo"></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
					<h4 class="admin"><i class="fa fa-2x fa-user-md fa-fw"></i><b>Doctor <?php echo $name;?><b></h4>
						<h6 class="text-center" style="color:green; margin-top:-10px;"><b>Available</b></h6>

						<ul class="nav" id="side-menu">
							<li class="divider"></li>
							
							<li>
							<a href="docHome.php"><i class="fa fa-lg fa-home fa-fw"></i> Home<i class="fa fa-lg arrow"></i></a>
						</li>
												
							<li class="currentLink"> 
								<a href="docProfile.php"><i class="fa fa-lg fa-user-md fa-fw"></i> Profile</a>
							</li>
							
							<li>
								<a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
							</li>
												
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Profile</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-10 col-md-12 col-sm-11 col-xs-11">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            My Profile
                        </div>
                        <!-- /.panel-heading -->
									
                        <div class="panel-body">
							<a onclick="showForm()" style="float:right;" id="editButton"><i class="fa fa-pencil fa-fw"></i> Edit Schedule</a>
							
							<div class="col-lg-5 col-md-5 col-sm-6"><br><br>
								<a id="docPhoto"><img class="img-thumbnail" src="img/faye.png"></a>
								<a onclick="showPhotoInput()" style="float:right;" id="changePhoto"><i class="fa fa-pencil fa-fw"></i> Change Photo</a>
								<input type="file" name="fileToUpload" id="fileToUpload" style="display:none;">
								<a href="#" class="btn btn-sub" id="submit" style="display:none;"><b>Submit</b></a> 	
								<a href="#" onclick="hidePhotoInput()" class="btn btn-sub" id="can" style="display:none;"><b>Cancel</b></a> 
							</div>
							
							<?php
						    require ("database.php");
							$sql="SELECT doctor.FirstName ,LEFT(doctor.MiddleName,1) as 'MiddleName',doctor.LastName,doctor.Specialization,doctor.ImageName,doctor.HealthCardID,doctor.Image,`health card accreditation`.HealthCardName from doctor RIGHT JOIN `health card accreditation` ON doctor.HealthCardID = `health card accreditation`.HealthCardID WHERE doctor.DoctorID ='".$doctorID."' "; 
							$result = mysqli_query($conn,$sql);
						
						?>	
							
							<div class="col-lg-7 col-md-7 col-sm-6" id="viewProfile">
							
							
							
								<form role="form"><br>
								
								<?php while ($doctor = mysqli_fetch_object($result)){?>
							 <label id="name">Name</label>
									<h4 id="fullName"><?php echo $doctor->FirstName;?> <?php echo $doctor->MiddleName;?>. <?php echo $doctor->LastName;?></h4>
									<label id="spec">Specializations</label>
									<h4 id="specList">
										<ul style="list-style-type:disc">
										 
										  <li><?php echo $doctor->Specialization;?></li>
										</ul>
									</h4>
																	
									<label id=hmo>HMO Accreditations</label>
									<h4 id="hmoList"><?php echo $doctor->HealthCardName;?></h4>
									<br>
									
					<?php } ?>
									
							
									<label id="hosp">Schedule</label>
									<?php
						    require ("database.php");
							$sql="SELECT DAYNAME(`schedule of doctor`.Date) as 'Days',`schedule of doctor`.ScheduleOut,`schedule of doctor`.ScheduleIn,hospital.HospitalName,`schedule of doctor`.AMPMIn,`schedule of doctor`.AMPMOut FROM `schedule of doctor` RIGHT JOIN hospital ON `schedule of doctor`.HospitalID = hospital.HospitalID WHERE `schedule of doctor`.DoctorID ='".$doctorID."' "; 
							$result1 = mysqli_query($conn,$sql);
						
						?>	
									<h4 id="hospList">
										<ul style="list-style-type:disc">
										
								<?php while ($doctor = mysqli_fetch_object($result1)){?>
								
								
							
										  <li><?php echo $doctor->Days;?></li>
										  <li><?php echo $doctor->HospitalName;?> | <?php echo $doctor->ScheduleIn;?> <?php echo $doctor->AMPMIn;?> -<?php echo $doctor->ScheduleOut;?><?php echo $doctor->AMPMOut;?></li>
			
										</ul>
									<?php } ?>
									
								</form>
							</div>
							
							<!-- Edit Profile (Default: Hidden)-->
							<div class="col-lg-7 col-md-7 col-sm-6" style="display:none;" id="editProfile">
								<form role="form"><br>
									<label id="update">Update Schedule</label>
									<select class="form-control" onchange="showSched(this.value)"id="selected">
										<option><em>- Choose Hospital -</em></option>
										
										<?php
				require 'database.php';
				$sql = "SELECT DAYNAME(`schedule of doctor`.Date) as 'Days',`schedule of doctor`.ScheduleOut,`schedule of doctor`.ScheduleIn,hospital.HospitalName,`schedule of doctor`.AMPMIn,`schedule of doctor`.AMPMOut FROM `schedule of doctor` RIGHT JOIN hospital ON `schedule of doctor`.HospitalID = hospital.HospitalID WHERE `schedule of doctor`.DoctorID ='".$doctorID."'";
				$stmt = mysqli_query($conn, $sql);
				while($row = mysqli_fetch_array($stmt))
					{   
						echo '<option value="1">'.$row['HospitalName'].'</option>';
					}
				?>
									</select>
									
              <?php
						    require ("database.php");
							$sql="SELECT DAYNAME(`schedule of doctor`.Date) as 'Days',`schedule of doctor`.ScheduleOut,`schedule of doctor`.ScheduleIn,hospital.HospitalName,`schedule of doctor`.AMPMIn,`schedule of doctor`.AMPMOut FROM `schedule of doctor` RIGHT JOIN hospital ON `schedule of doctor`.HospitalID = hospital.HospitalID WHERE `schedule of doctor`.DoctorID ='".$doctorID."'"; 
							$result1 = mysqli_query($conn,$sql);
						
						?>	
						    <table class="table table-hover table-bordered table-fixed" style="display:none;" id="changeSched">
										<thead><tr>
											<th>Day</th>
											<th>Start Time</th>
											<th>End Time</th>
											<th>Action</th>
										</tr></thead>
										<tbody>
										 <?php while ($schedule = mysqli_fetch_object($result1)){?>
											<tr class="gradeA">
												<td><?php echo $schedule->Days;?></td>
												<td><?php echo $schedule->ScheduleIn;?><?php echo $schedule->AMPMIn;?></td>
												<td><?php echo $schedule->ScheduleOut;?><?php echo $schedule->AMPMOut;?></td>
												<th><a href=""><i class="fa fa-pencil fa-fw"></i> Edit </a>  | <a onclick="showProfileAndRecords()"><i class="fa fa-close fa-fw"></i> Delete</a></th>
											</tr>
										<?php } ?>
											
										</tbody>
									</table>		
									
									<a href="#" class="btn btn-sub" id="save"><b>Save</b></a> 	
									<a href="#" class="btn btn-can" id="cancel" onclick="hideForm()"><b>Cancel</b></a>
								</form>
							</div>
                        </div> 
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
				               
            </div>
            <!-- /.row -->
         
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

     <!-- jQuery -->
    <script src="js/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>

	<script src="js/metisMenu.min.js"></script> 

	<script src="js/docJS.js"></script>
	
</body>

</html>
