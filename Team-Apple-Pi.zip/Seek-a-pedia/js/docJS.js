/* Doctor Edit Status */



/* Doctor Edit Profile */
function showForm() {
	document.getElementById('editButton').style.display = "none";
	document.getElementById('viewProfile').style.display = "none";
	document.getElementById('editProfile').style.display = "block";
}

function hideForm() {
	document.getElementById('editButton').style.display = "block";
	document.getElementById('viewProfile').style.display = "block";
	document.getElementById('editProfile').style.display = "none";
}

function showPhotoInput() {
	document.getElementById('changePhoto').style.display = "none";
	document.getElementById('fileToUpload').style.display = "block";
	document.getElementById('submit').style.display = "inline-block";
	document.getElementById('can').style.display = "inline-block";
}

function hidePhotoInput() {
	document.getElementById('changePhoto').style.display = "block";
	document.getElementById('fileToUpload').style.display = "none";
	document.getElementById('submit').style.display = "none";
	document.getElementById('can').style.display = "none";
}

function showSched(value) {
	
	if (value>0){document.getElementById('changeSched').style.display = "block";}
	
}

/* Doctor Patients Today */
var clicked = true;
var clicked2 = true;
		
function showDetails() {
	if (clicked) {
		document.getElementById('hospSched').style.display = "block";
		clicked = false;
	} else {
		document.getElementById('hospSched').style.display = "none";
		clicked = true;
	}
			
}
		
function showPatientsList() {
	if (clicked2) {
		document.getElementById('view').style.display = "none";
		document.getElementById('hide').style.display = "block";
		document.getElementById('right').style.display = "none";
		document.getElementById('left').style.display = "block";
		document.getElementById('list').style.display = "block";
		clicked2 = false;
	} else {
		document.getElementById('view').style.display = "block";
		document.getElementById('hide').style.display = "none";
		document.getElementById('right').style.display = "block";
		document.getElementById('left').style.display = "none";
		document.getElementById('list').style.display = "none";
		clicked2 = true;
	}
}


/* Doctor Patients */
var clicked3 = false;
		
function showProfileAndRecords() {
	if (clicked) {
		document.getElementById('searchPatient').style.display = "none";
		document.getElementById('patientProfile').style.display = "block";
		document.getElementById('patientRecords').style.display = "block";
		document.getElementById('brePatients').style.display = "inline-block"
		document.getElementById('active').innerHTML = "Patient Record";
				document.getElementById('active').style.display = "inline-block";
		clicked = true;
	} 	
}

function showPatientRecs(){
	document.getElementById('patientRecs').style.display = "block";
}

