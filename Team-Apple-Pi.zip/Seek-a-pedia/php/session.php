<?php
	require("php/database.php");
	session_start();// Starting Session
	// Storing Session
	$user_check=$_SESSION['login_user'];
	// SQL Query To Fetch Complete Information Of User
	$sql="SELECT account.AccountID,account.Username,doctor.DoctorID,doctor.Firstname,doctor.Specialization,COUNT(AppointmentID) as 'Number of appointment',appointment.PatientID FROM doctor LEFT JOIN account ON account.AccountID = doctor.AccountID LEFT JOIN appointment ON doctor.DoctorID = appointment.DoctorID WHERE account.Username ='".$user_check."'";
	$res = mysqli_query($conn,$sql);
	$row = mysqli_fetch_array($res);
	$login_session = $row['Username'];

	$name = $row['Firstname'];
	$accountID = $row['AccountID'];
	$doctorID = $row['DoctorID'];
	$num = $row['Number of appointment'];
	$patientID = $row['PatientID'];
	

	if(!isset($login_session)){
		mysqli_close($connection); // Closing Connection
		header('Location: docLogin.php'); // Redirecting To Home Page
	}
?>